# ABAP Custom Developments

This folder contains all custom ABAP developments for the MDG Material Master with IDOC Distribution project.

## Contents

### 1. BADI Implementations (`/badi-implementations/`)

#### zcl_usmd_matl_validation.abap
**Purpose**: Custom validation rules for material master data before activation

**BADI**: `USMD_RULE_SERVICE_BADI_MATL`  
**Method**: `CHECK_ENTITY`

**Validations Performed**:
- Duplicate material description check
- Mandatory field validation (Description, Base UOM, Material Type, Material Group)
- Plant existence validation
- Material type-specific business rules

**Usage**:
```abap
" This BADI is automatically called during change request activation
" No manual invocation needed
```

**Testing**:
1. Create material without description → Should error
2. Create material with duplicate description → Should error
3. Create material with invalid plant → Should error

---

### 2. IDOC Enhancements (`/idoc-enhancements/`)

#### zcl_usmd_idoc_filter.abap
**Purpose**: Filter plant-specific data before IDOC distribution

**BADI**: `USMD_IDOC_FILTER`  
**Method**: `FILTER_IDOC_DATA`

**Filtering Logic**:
- Maps receiver logical system to plant code
- Removes E1MARCM segments not belonging to target plant
- Removes E1MBEWM segments not belonging to target valuation area
- Optionally adds custom Z-segments

**Example**:
```
Material has data for Plant 1000 and 2000
IDOC to PLANT1_100 → Contains only Plant 1000 data
IDOC to PLANT2_100 → Contains only Plant 2000 data
```

**Testing**:
1. Create material with multi-plant data
2. Check IDOC segments with WE19
3. Verify only relevant plant data is sent

---

### 3. Error Handling (`/error-handling/`)

#### z_mdg_idoc_error_monitor.abap
**Purpose**: Monitor and reprocess failed MDG Material IDOCs

**Program Type**: Executable Report  
**Transaction Code**: `ZIDOCMON` (create custom)

**Features**:
- Lists all failed IDOCs by date range
- Displays error details and material numbers
- Automatic reprocessing for technical errors (Status 64, 68)
- Email notification for critical errors
- Export error list for analysis

**Selection Screen Parameters**:
```
Date Range:       DATEFR to DATETO
Message Type:     MATMAS (default)
IDOC Type:        MATMAS05 (default)
Reprocess Flag:   Checkbox to enable auto-reprocessing
Detail View:      Show detailed error information
Email Alert:      Send email summary
Email To:         Recipient email address
```

**Scheduling**:
Schedule as hourly background job:
```
Transaction: SM36
Job Name:    Z_MDG_IDOC_MONITOR_HOURLY
Frequency:   Every hour
Program:     Z_MDG_IDOC_ERROR_MONITOR
Variant:     Default (last 24 hours)
```

**Output Example**:
```
══════════════════════════════════════════════════
         MDG IDOC ERROR MONITORING REPORT
══════════════════════════════════════════════════

Date Range      : 05/10/2026 - 05/15/2026
Message Type    : MATMAS
IDOC Type       : MATMAS05

SUMMARY
──────────────────────────────────────────────────
Total Errors    : 5
  Status 51 (Application Error)     : 2
  Status 64 (Ready for transfer)    : 1
  Status 68 (Error in ALE service)  : 2

DETAILED ERROR LIST
──────────────────────────────────────────────────
IDOC: 0000000123456789
Status: 51
Material: M-TEST-001
Error: Base UOM TON does not exist in target system
Action: Requires manual correction
```

---

## Installation Instructions

### Step 1: Create BADI Implementations

**Transaction**: `SE19`

1. Create Enhancement Implementation:
   ```
   Implementation: Z_USMD_MATL_IMPL
   Enhancement Spot: USMD_CUSTOMER
   ```

2. Add BADI Definition: `USMD_RULE_SERVICE_BADI_MATL`
   - Implementing Class: `ZCL_USMD_MATL_VALIDATION`
   - Copy code from `zcl_usmd_matl_validation.abap`

3. Add BADI Definition: `USMD_IDOC_FILTER`
   - Implementing Class: `ZCL_USMD_IDOC_FILTER`
   - Copy code from `zcl_usmd_idoc_filter.abap`

4. Activate implementation

### Step 2: Create Error Monitoring Program

**Transaction**: `SE38`

1. Create new program: `Z_MDG_IDOC_ERROR_MONITOR`
2. Copy code from `z_mdg_idoc_error_monitor.abap`
3. Activate program
4. Create transaction code: `ZIDOCMON`
   - Transaction: `SE93`
   - Program: `Z_MDG_IDOC_ERROR_MONITOR`
   - Type: Report transaction

### Step 3: Create Message Class

**Transaction**: `SE91`

Create message class: `ZMDG_MSG`

| Message No | Message Text |
|-----------|--------------|
| 001 | Material description & already exists |
| 002 | Field & is mandatory |
| 003 | & & does not exist |
| 004 | & |
| 005 | & |
| 006 | & |

### Step 4: Transport

1. Create transport request
2. Add all objects:
   - Enhancement implementation
   - ABAP classes (2)
   - ABAP program (1)
   - Message class
   - Transaction code
3. Release transport
4. Import to QAS and PRD

---

## Customization Guide

### Adding New Validation Rules

Edit `zcl_usmd_matl_validation.abap`:

```abap
METHOD if_usmd_rule_service_badi~check_entity.
  
  " Add your validation here
  IF <your_condition>.
    APPEND VALUE #(
      msgty = 'E'          " E=Error, W=Warning, I=Info
      msgid = 'ZMDG_MSG'
      msgno = '007'        " Create new message number
      attr1 = 'Field name'
    ) TO et_message.
  ENDIF.

ENDMETHOD.
```

### Customizing IDOC Filter

Edit `zcl_usmd_idoc_filter.abap`:

```abap
METHOD get_plant_for_receiver.
  
  " Add your logical system mapping
  CASE iv_receiver_ls.
    WHEN 'YOUR_LS'.
      rv_plant = 'YOUR_PLANT'.
  ENDCASE.

ENDMETHOD.
```

### Enhancing Error Monitor

Edit `z_mdg_idoc_error_monitor.abap`:

Add custom error handling in `FORM reprocess_idocs`:
```abap
" Add custom logic before reprocessing
IF gs_error_idoc-status = '51'.
  " Custom handling for application errors
  PERFORM custom_error_correction.
ENDIF.
```

---

## Testing Guide

### Unit Testing BADI

**Method 1: Direct Testing**
```
1. Create test change request
2. Enter invalid data (e.g., missing mandatory field)
3. Try to activate
4. Expected: Validation error displayed
```

**Method 2: Debugging**
```
1. Set breakpoint in BADI class
2. Create change request
3. Activate → Debugger stops at breakpoint
4. Step through validation logic
```

### Unit Testing IDOC Filter

```
1. Create material with multi-plant data
2. Activate
3. Transaction: WE19
4. Display generated IDOC
5. Verify plant filtering worked correctly
```

### Testing Error Monitor

```
1. Create intentional IDOC errors
2. Run: Z_MDG_IDOC_ERROR_MONITOR
3. Check report output
4. Enable reprocessing flag
5. Verify successful reprocessing
```

---

## Performance Considerations

### BADI Performance
- Keep validation logic efficient
- Avoid nested loops in validation
- Use database buffering where possible
- Consider batch validation for bulk uploads

### IDOC Filter Performance
- Filter logic runs per IDOC
- Optimize segment deletion logic
- Minimize database calls

### Error Monitor Performance
- Schedule during off-peak hours if processing large volumes
- Use date range filters to limit dataset
- Archive old error logs regularly

---

## Troubleshooting

### BADI Not Triggering

**Check**:
1. BADI implementation is active (SE19)
2. Enhancement spot is active
3. No syntax errors in code

**Debug**:
```
Set breakpoint: /h in command field
Create test CR and activate
```

### IDOC Filter Not Working

**Check**:
1. Logical system mapping is correct
2. Plant codes match exactly (case-sensitive)
3. BADI is active

**Debug**:
```
Set breakpoint in method FILTER_IDOC_DATA
Create material and activate
Step through filtering logic
```

### Error Monitor Shows No Results

**Check**:
1. Date range includes error IDOCs
2. Message type is correct (MATMAS)
3. Status codes are in selection (51, 64, 68)

**Verify**:
```
Transaction: WE02
Check if any error IDOCs exist manually
```

---

## Change Log

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | May 2026 | Madhuri | Initial version - Validation BADI, IDOC Filter, Error Monitor |

---

## Support & Contact

For issues or enhancements:
- **Developer**: Madhuri - SAP MDG Consultant
- **Support Email**: mdg-support@company.com
- **Documentation**: See `/docs` folder for detailed guides
