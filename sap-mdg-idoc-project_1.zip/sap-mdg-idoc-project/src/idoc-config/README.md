# IDOC Configuration Files

This folder contains IDOC-related configuration documentation and settings.

## Contents

### Partner Profiles (`/partner-profiles/`)

**WE20 Configuration Documentation**

Configured partners:
- **PLANT1_100** - Plant 1 System (RFC: SAPPLANT1)
- **PLANT2_100** - Plant 2 System (RFC: SAPPLANT2)
- **PLANT3_100** - Plant 3 System (RFC: SAPPLANT3)

**Outbound Parameters** (MDG Hub):
```
Message Type:     MATMAS
Receiver Port:    SAP<PLANT_NAME>
Pack Size:        1
Output Mode:      Transfer IDocs Immediately
Basic Type:       MATMAS05
```

**Inbound Parameters** (Plant Systems):
```
Message Type:     MATMAS
Process Code:     MATM
Processing Type:  Trigger Immediately
Function Module:  IDOC_INPUT_MATMAS
```

---

### Message Types (`/message-types/`)

**WE81 Message Type Configuration**

**MATMAS - Material Master**
```
Message Type:     MATMAS
Description:      Material Master Distribution
Direction:        Outbound
Basic Type:       MATMAS05
Application:      Material Master (MM)
```

**Supported Operations**:
- Create Material (MSGFN = 009)
- Change Material (MSGFN = 004)
- Delete Material (MSGFN = 003)

---

### Distribution Model (`/distribution-model/`)

**BD64 Model Configuration**

**Model**: Z_MDG_MATMAS_DIST

**Distribution Rules**:

| Sender | Receiver | Message Type | Filter Object | Filter Condition |
|--------|----------|--------------|---------------|------------------|
| MDGHUB_100 | PLANT1_100 | MATMAS | MARC | WERKS = 1000 |
| MDGHUB_100 | PLANT2_100 | MATMAS | MARC | WERKS = 2000 |
| MDGHUB_100 | PLANT3_100 | MATMAS | MARC | WERKS = 3000 |

**Filter Logic**: Only materials with plant data for the specific plant are distributed to that plant system.

---

## IDOC Type Structure - MATMAS05

```
MATMAS05
├── EDI_DC40 (Control Record)
│   ├── TABNAM    = EDI_DC40
│   ├── MANDT     = 100
│   ├── DOCNUM    = (Generated)
│   ├── DOCREL    = 740
│   ├── STATUS    = (Status code)
│   ├── DIRECT    = 1 (Outbound)
│   ├── IDOCTYP   = MATMAS05
│   ├── MESTYP    = MATMAS
│   ├── SNDPOR    = SAPMDG
│   ├── SNDPRN    = MDGHUB_100
│   ├── RCVPOR    = SAP<PLANT>
│   └── RCVPRN    = PLANT<X>_100
│
├── E1MARAM (Material Header)
│   ├── MSGFN     = 009 (Create) / 004 (Change)
│   ├── MATNR     = (Material Number)
│   ├── MTART     = (Material Type)
│   ├── MEINS     = (Base UOM)
│   ├── MATKL     = (Material Group)
│   └── ... (Other MARA fields)
│
├── E1MAKTM (Description - Multiple for languages)
│   ├── MSGFN     = 009 / 004
│   ├── MAKTX     = (Description)
│   └── SPRAS     = EN / DE / etc.
│
├── E1MARCM (Plant Data - One per plant)
│   ├── MSGFN     = 009 / 004
│   ├── WERKS     = (Plant)
│   ├── DISMM     = (MRP Type)
│   ├── DISPO     = (MRP Controller)
│   ├── DISLS     = (Lot Size)
│   ├── EISBE     = (Safety Stock)
│   └── ... (Other MARC fields)
│
├── E1MBEWM (Valuation - One per valuation area)
│   ├── MSGFN     = 009 / 004
│   ├── BWKEY     = (Valuation Area = Plant)
│   ├── VPRSV     = (Price Control)
│   ├── STPRS     = (Standard Price)
│   └── ... (Other MBEW fields)
│
└── E1MEANM (EAN/UPC - Optional)
    ├── MSGFN     = 009 / 004
    └── EAN11     = (EAN Number)
```

---

## IDOC Status Codes

### Success Codes
| Status | Description |
|--------|-------------|
| 01 | IDOC created |
| 02 | Error passing data to port |
| 03 | Data passed to port OK |
| 12 | Dispatch OK |
| 30 | IDOC ready for dispatch (ALE service) |
| 53 | Posted (Successfully processed) |

### Error Codes
| Status | Description | Action Required |
|--------|-------------|-----------------|
| 51 | Application document not posted | Check data validity, correct and reprocess |
| 64 | IDOC ready to be passed to application | Technical issue, auto-retry or manual reprocess |
| 68 | Error in ALE service | Check RFC connection, auto-retry configured |

---

## Configuration Steps

### 1. Logical System Setup (SALE)

```
Transaction: SALE → Basic Settings → Logical Systems

Create:
- MDGHUB_100   (MDG Central Hub)
- PLANT1_100   (Plant 1)
- PLANT2_100   (Plant 2)  
- PLANT3_100   (Plant 3)

Assign to clients via SCC4
```

---

### 2. RFC Destination Setup (SM59)

```
For each plant system:

RFC Destination:  SAP<PLANT_NAME>
Connection Type:  3 (ABAP Connection)
Description:      Connection to Plant <X> System
Target Host:      <hostname>
System Number:    <sysnr>
Client:           <client>

Test: Connection Test + Remote Logon
```

---

### 3. Port Definition (WE21)

```
For each plant:

Port Name:        SAP<PLANT_NAME>
Description:      tRFC Port to Plant <X>
RFC Destination:  SAP<PLANT_NAME>
```

---

### 4. Partner Profile (WE20)

**On MDG Hub (Outbound)**:
```
Partner Number:   PLANT<X>_100
Partner Type:     LS (Logical System)

Outbound Parameters:
  Message Type:   MATMAS
  Receiver Port:  SAP<PLANT_NAME>
  Output Mode:    Transfer IDocs Immediately
```

**On Plant Systems (Inbound)**:
```
Partner Number:   MDGHUB_100
Partner Type:     LS

Inbound Parameters:
  Message Type:   MATMAS
  Process Code:   MATM
  Processing:     Trigger Immediately
```

---

### 5. Distribution Model (BD64)

```
Create Model:     Z_MDG_MATMAS_DIST
Add View:         Material Master Distribution

Add Receiver:     PLANT1_100
  Message Type:   MATMAS
  Filter:         MARC-WERKS = 1000

Repeat for PLANT2_100 and PLANT3_100

Generate Partner Profiles
```

---

## Testing IDOC Configuration

### Test 1: IDOC Creation (WE19)

```
1. Transaction: WE19
2. Create new IDOC
3. Basic Type: MATMAS05
4. Fill test data
5. Standard Outbound Processing
6. Check IDOC created in WE02
```

---

### Test 2: End-to-End Test

```
1. Create material in MDG
2. Activate change request  
3. Check IDOC generated (WE05)
4. Verify IDOC sent (Status 03)
5. Check target system (WE02)
6. Verify material created (SE16 → MARA/MARC)
```

---

### Test 3: Error Scenario

```
1. Simulate error (invalid data)
2. Check IDOC status in WE02
3. Review error message
4. Correct data
5. Reprocess IDOC (BD87)
6. Verify success
```

---

## Troubleshooting

### IDOC Not Generated

**Check**:
1. Distribution model active (BD64)
2. Partner profile configured (WE20)
3. Output type configured (NACE)
4. Activation successful

---

### IDOC Status 51 (Application Error)

**Common Causes**:
- Invalid material type in target
- Invalid UOM not in T006
- Missing plant in T001W
- Invalid material group

**Resolution**:
1. Check error text in WE02
2. Correct data in MDG
3. Reactivate or reprocess IDOC

---

### IDOC Status 68 (ALE Service Error)

**Common Causes**:
- RFC connection down
- Port not configured
- Authorization issues

**Resolution**:
1. Test RFC connection (SM59)
2. Check port definition (WE21)
3. Review authorization (S_IDOC_*)
4. Auto-retry will trigger

---

## Performance Tuning

### Parallel Processing

Enable parallel IDOC processing:
```
Transaction: RBDMOIND
Configure parallel processes for MATMAS
Typical: 3-5 parallel processes
```

### Packet Size

Adjust packet size for bulk operations:
```
Transaction: WE20
Partner Profile → Outbound Parameters
Pack Size: 1 (real-time) or 100 (batch)
```

### Archiving

Archive old IDOCs regularly:
```
Transaction: SARA
Object: IDOC
Archive after: 90 days
Delete after archiving
```

---

## Monitoring

### Daily Checks

1. Run error monitoring report (Z_MDG_IDOC_ERROR_MONITOR)
2. Review WE05 for failed IDOCs
3. Check system logs (SM21)
4. Monitor RFC connections (SM59)

### Weekly Review

1. IDOC volume trends
2. Success rate analysis
3. Performance metrics
4. Error patterns

---

## Related Documentation

- **Setup Guide**: `/docs/setup-guide.md` - Detailed configuration steps
- **Technical Design**: `/docs/technical-design.md` - Architecture and design
- **Testing Guide**: `/docs/testing-guide.md` - IDOC test scenarios

---

**Maintained By**: Madhuri - SAP MDG Consultant  
**Last Updated**: May 2026
